   <!-- Product -->
   <section id="product">
        <h1>
            PAKET KAMI LAINNYA
        </h1>
        <div class="line"><img src="img/line.png" alt="garis batas"></div>
        <div class="container">
            <div class="box">
                <img src="img/raf4-min.jpg" alt="paket rafting pacet">
                <h2>Paket Tos Rafting Pacet</h2> 
                <p>*mulai harga :</p>
                <p>RP. 150.000,-/ORANG</p>
                <button onclick="window.location.href='tos-rafting-Pacet'"> <strong>Selengkapnya</strong> </button>
            </div>
            <div class="box">
                <img src="img/out2.jpg" alt="paket outbound pacet">
                <h2>Paket Tos Outbound Pacet</h2> 
                <p>*mulai harga :</p>
                <p>RP. 175.000,-/ORANG</p>
                <button onclick="window.location.href='tos-outbound-Pacet'"><strong>Selengkapnya</strong></button>
            </div>
            <div class="box">
                <img src="img/pain2.jpg" alt="paket paintball pacet">
                <h2>Paket Tos Paintball Pacet</h2> 
                <p>*mulai harga :</p>
                <p>RP. 150.000,-/ORANG</p>
                <button onclick="window.location.href='tos-paintball-Pacet'"><strong>Selengkapnya</strong></button>
            </div>
            <div class="box">
                <img src="img/camp1.jpg" alt="info paket lain">
                <h2>Paket Tos Adventure lain</h2> 
                <p>*mulai harga :</p>
                <p>KONTAK UNTUK HARGA</p>
                <button onclick="window.location.href='#contact'"><strong>Selengkapnya</strong></button>
            </div>
        </div>
    </section>

    <!-- end product -->