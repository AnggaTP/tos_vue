<footer>
    <div class="container">
            <div class="box">
                <img src="img/new_tos11.png" alt="emblem tos adventure pacet">
            </div>
            <div class="box">
               
                <h3>LINK TOS ADVENTURE PACET</h3> 
                <ul>
                    <li><a href="tos-rafting-Pacet">> Rafting Pacet</a></li>
                    <li><a href="tos-outbound-Pacet">> Outbound Pacet</a></li>
                    <li><a href="Htos-paintball-Pacet">> Paintball Pacet</a></li>
                    <li><a href="sewa-villa-Pacet">> Villa Pacet</a></li>
                    <li><a href="kontak-dan-reservasi">> Info Reservasi</a></li>
                </ul>
            </div>
            <div class="box">
                
                <h3>TEMUKAN TOS ADVENTURE PACET</h3> 
                <ul>
                    <li><span class="fa fa-fort-awesome"></span> Basecamp : Wana Wisata Air Panas Pacet Mojokerto</li>
                    <li><span class="fa fa-home"></span> Kantor : Blok E-3 Perum Taman Majapahit Jabon Mojokerto</li>
                    <li><span class="fa fa-phone"></span> Office : 0321-6855054</li>
                    <li><span class="fa fa-envelope"></span> Email : pacetraftingtos@gmail.com</li>
                </ul>
            </div>
            <div class="box">
                
                <h3>KONTAK TOS ADVENTURE PACET</h3> 
                <ul>
                    <li><span class="fa fa-phone"></span> 082231372191 / NAVIS ZARKASY</li>
                    <li><span class="fa fa-phone"></span> 081234557490 / MUSLIHUDDIN</li>
                    <li><span class="fa fa-phone"></span> 085156244623 (OFFICE WA CHAT ONLY)</li>
                    
                </ul>
            </div>

        </div> 
    </footer>