<section id="contact">
        <div class="container">
            <h2>KONTAK TOS ADVENTURE PACET</h2>
            <!-- <div class="line"><img src="img/line.png" alt=""></div> -->
            <p>Tunggu apalagi? Segera hubungi kontak kami dibawah atau langsung meluncur ke basecamp kami..</p>
                <p>TOS ADVENTURE PACET Enjoy The Flow Feel The Nature.</p>
            <div class="box-grid">
                <div class="box">
                    <ul>
                        <li><span class="fa fa-fort-awesome"></span> Basecamp : Wana Wisata Air Panas Pacet Mojokerto</li>
                        <li><span class="fa fa-home"></span> Kantor : Blok E-3 Perum Taman Majapahit Jabon Mojokerto</li>
                        <li><span class="fa fa-phone"></span> Office : 0321-6855054/ 085156244623 (WA Chat Only)</li>
                        <li><span class="fa fa-phone"></span> 082231372191 / Navis Zarkasy</li>
                        <li><span class="fa fa-phone"></span> 081234557490 / Muslihuddin</li>
                        <li><span class="fa fa-envelope"></span> Email : pacetraftingtos@gmail.com</li>
                        
                    </ul>
                </div>
                <div class="box">
                    <a href="https://goo.gl/maps/6pJgvw71Z4jddrKj8" target="_blank">
                        <img src="img/peta-tos.jpg" alt="lokasi tos">
                    </a>

                </div>
                <div class="box-sosmed">
                    <p>SOCIAL MEDIA KAMI</p>
                    <ul>
                        <li><a href="https://www.instagram.com/tosraftingpacet/" target="_blank"><i class="fa fa-instagram"></i><p>@tosraftingpacet</p></a></li>
                        <li><a href="https://www.facebook.com/TOSPACET/" target="_blank"><i class="fa fa-facebook"></i><p>tospacet</p></a></li>
                    </ul>
                </div>
            </div>
            
        </div>
    </section>